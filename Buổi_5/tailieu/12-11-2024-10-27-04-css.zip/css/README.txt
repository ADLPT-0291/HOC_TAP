# CSS: có 3 dạng
- 😁 Inline CSS -> có độ ưu tiên cao nhất (1)
- 😁 External CSS -> (2) Thằng nào nằm sau thì có độ ưu tiên cao hơn - selector giống nhau
- 🤔 Internal CSS -> (2) Thằng nào nằm sau thì có độ ưu tiên cao hơn - selector giống nhau

# Độ ưu tiên selector 
- tag: 1
- class: 10
- id: 100